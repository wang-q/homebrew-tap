# A simplified version of MaSuRCA-3.2.1

This is a simplified version of MaSuRCA for creating super-reads.

Original url is [here](ftp://ftp.genome.umd.edu/pub/MaSuRCA/beta/SuperReads_RNA-1.0.1.tar.gz).

I revert C++ files in `global-1/SuperReadsR/` to the corresponding file of MaSuRCA-3.1.3 as the new
one creates some misassemblies.
